function insta() {
    window.open('https://instagram.com/')
}